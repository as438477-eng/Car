const C='car-v1',A=['./','index.html','manifest.webmanifest','icon-192.png','icon-512.png'],T=['tess/tesseract.min.js','tess/worker.min.js','tess/tesseract-core-lstm.wasm.js','tess/tesseract-core-simd-lstm.wasm.js','tess/eng.traineddata.gz'];
self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(A).then(()=>Promise.all(T.map(u=>c.add(u).catch(()=>{}))))).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!=C).map(x=>caches.delete(x)))).then(()=>clients.claim())));
self.addEventListener('fetch',e=>{const q=e.request;if(q.method!='GET')return;
 if(q.mode=='navigate'){e.respondWith(fetch(q).then(r=>{const k=r.clone();caches.open(C).then(c=>c.put('index.html',k));return r}).catch(()=>caches.match('index.html')));return}
 e.respondWith(caches.match(q).then(r=>r||fetch(q).then(x=>{if(x.ok&&new URL(q.url).origin==location.origin){const k=x.clone();caches.open(C).then(c=>c.put(q,k))}return x})))});
